java -Xmx6g  -XX:MaxPermSize=4G -cp $CLASSPATH:./class esl.PrepositionCorrector testES.column >outputFile
