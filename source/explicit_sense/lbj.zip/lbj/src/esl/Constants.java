package esl;

public class Constants
{
public static final String trainingData = "trainES.column";
 
}
