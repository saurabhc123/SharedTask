package esl;

public class Constants
{
 //  public static final String trainingData = "article.train";
	public static final String trainingData = "/scratch/rozovska/learner/prep/esl/trainFile";
 
}
